LIMON OCTAPAD — Android Studio project

এই ZIP-টি Android APK তৈরির সোর্স প্রজেক্ট; এটি নিজে APK ফাইল নয়।

APK বানানোর ধাপ:
1. কম্পিউটারে Android Studio ইনস্টল করুন।
2. Android Studio থেকে এই ZIP Extract করে Open করুন (LIMON_OCTAPAD_Android ফোল্ডার)।
3. Gradle Sync শেষ হতে দিন এবং Android SDK Platform 35 ইনস্টল করুন।
4. Build > Build Bundle(s) / APK(s) > Build APK(s) চাপুন।
5. APK তৈরি হবে: app/build/outputs/apk/debug/app-debug.apk

ফোনে ইনস্টল:
APK ফোনে কপি করে খুলুন। Android চাইলে “Install unknown apps” অনুমতি দিন।

অ্যাপের নাম: LIMON OCTAPAD
Package: com.limon.octapad
দিক: Landscape
এতে মূল HTML Octapad অ্যাপটি Android WebView-তে চলে। TONE UPLOAD-এর জন্য Android ফাইল পিকার যুক্ত করা হয়েছে।

মোবাইল ফোন দিয়েই APK বানানোর সহজ উপায় (GitHub Actions):
1. ZIP Extract করুন এবং GitHub-এ নতুন repository তৈরি করুন।
2. Extract করা প্রজেক্টের সব ফাইল repository-তে Upload files দিয়ে আপলোড করুন। .github/workflows/android.yml ফাইলটিও থাকতে হবে।
3. Commit changes দিন।
4. Repository-এর Actions ট্যাব খুলুন; "Build LIMON OCTAPAD APK" workflow চালু করুন (প্রয়োজনে Run workflow চাপুন)।
5. Build সফল হলে workflow run-এর নিচের Artifacts থেকে LIMON-OCTAPAD-APK ডাউনলোড করুন।
6. ZIP extract করে app-debug.apk খুলে Install দিন।
নোট: GitHub অ্যাকাউন্ট এবং ইন্টারনেট দরকার হবে। APKটি debug-signed; Play Store প্রকাশের signed release নয়।
